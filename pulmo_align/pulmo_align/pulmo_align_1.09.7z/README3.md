# PulmoAlign - Documentación Técnica Extendida

## 1. Sistema de Coordenadas y Regiones de Búsqueda

### 1.1 Estructura de Coordenadas
El sistema utiliza 15 puntos anatómicos clave distribuidos estratégicamente:

```
Coord1-Coord15: {
    "sup": valor_superior,
    "inf": valor_inferior,
    "left": valor_izquierdo,
    "right": valor_derecho,
    "width": ancho_roi,
    "height": alto_roi
}
```

### 1.2 Regiones de Búsqueda
Para cada punto anatómico se define una región de búsqueda específica:

- Coord1: Región superior izquierda (17×17 puntos, y ∈ [23,39], x ∈ [1,17])
- Coord2: Región superior derecha (25×13 puntos, y ∈ [27,39], x ∈ [39,63])
- Coord3: Región lateral izquierda (15×19 puntos, y ∈ [4,22], x ∈ [12,26])
- Coord4: Región lateral derecha (17×23 puntos, y ∈ [39,61], x ∈ [11,27])
- Coord5-Coord15: Regiones específicas con dimensiones variables

### 1.3 Indexación de Imágenes
El sistema utiliza un esquema de indexación triple:
```
índice,categoría,número_imagen
donde:
- categoría: 1 (COVID), 2 (Normal), 3 (Viral Pneumonia)
- número_imagen: identificador único dentro de cada categoría
```

## 2. Procesamiento de Imágenes

### 2.1 Preprocesamiento
a) **Normalización Inicial**:
```python
image_normalized = image.astype(float) / 255.0
```

b) **Mejora de Contraste SAHS**:
1. Análisis estadístico del histograma:
```python
mean_global = np.mean(image)
above_mean = image[image > mean_global]
below_mean = image[image <= mean_global]
```

2. Cálculo de límites adaptativos:
```python
std_above = np.sqrt(np.mean((above_mean - mean_global) ** 2))
std_below = np.sqrt(np.mean((below_mean - mean_global) ** 2))
max_value = mean_global + 2.5 * std_above
min_value = mean_global - 2.0 * std_below
```

3. Normalización asimétrica:
```python
enhanced = 255 * (image - min_value) / (max_value - min_value)
enhanced = np.clip(enhanced, 0, 255)
```

### 2.2 Extracción de ROI
Para cada punto anatómico:

1. Cálculo de coordenadas:
```python
start_x = center_x - width//2
start_y = center_y - height//2
end_x = start_x + width
end_y = start_y + height
```

2. Ajuste por desplazamiento:
```python
dx = new_x - intersection_x
dy = new_y - intersection_y
adjusted_x = center_x + dx
adjusted_y = center_y + dy
```

3. Validación y extracción:
```python
roi = image[max(0,start_y):min(end_y,height),
           max(0,start_x):min(end_x,width)]
```

## 3. Análisis PCA y Búsqueda

### 3.1 Entrenamiento PCA
a) **Preparación de Datos**:
```python
X = np.array([img.flatten() for img in training_images])
X_centered = X - np.mean(X, axis=0)
```

b) **Descomposición**:
```python
covariance = (1/n) * X_centered.T @ X_centered
eigenvalues, eigenvectors = np.linalg.eigh(covariance)
```

c) **Selección de Componentes**:
```python
variance_ratio = eigenvalues.cumsum() / eigenvalues.sum()
k = np.argmax(variance_ratio >= threshold) + 1
V_k = eigenvectors[:,:k]  # k principales eigenvectores
```

### 3.2 Proceso de Búsqueda
Para cada coordenada candidata:

1. Extracción y preprocesamiento:
```python
roi = extract_roi(image, x, y, width, height)
roi_normalized = preprocess(roi)
```

2. Proyección y reconstrucción:
```python
omega = V_k.T @ (roi_normalized - mean_face)
reconstruction = mean_face + V_k @ omega
```

3. Cálculo de error:
```python
error = np.linalg.norm(roi_normalized - reconstruction)
```

### 3.3 Optimización
El proceso de búsqueda implementa:

a) **Búsqueda Exhaustiva**:
- Evaluación sistemática de todas las coordenadas candidatas
- Registro de errores para análisis estadístico
- Identificación del mínimo global

b) **Refinamiento Local**:
- Análisis detallado alrededor del mínimo encontrado
- Validación de estabilidad de la solución
- Verificación de consistencia geométrica

## 4. Visualización y Análisis de Resultados

### 4.1 Visualización Individual
Para cada punto anatómico:

a) **Mapa de Error**:
```python
plt.imshow(error_matrix, cmap='hot')
plt.colorbar(label='Error de Reconstrucción')
```

b) **Trayectoria de Búsqueda**:
```python
plt.scatter(coords[:,0], coords[:,1], c=errors, cmap='viridis')
plt.plot(best_x, best_y, 'r*', markersize=15)
```

### 4.2 Visualización Combinada
Integración de resultados múltiples:

a) **Superposición de Puntos**:
```python
for coord_name, result in results.items():
    x, y = result['min_error_coords']
    plt.plot(x, y, 'g*', label=coord_name)
```

b) **Análisis de Relaciones**:
```python
distances = calculate_pairwise_distances(coordinates)
plt.hist(distances, bins='auto', density=True)
```

### 4.3 Análisis Estadístico
Para cada punto anatómico:

a) **Distribución de Errores**:
```python
mean_error = np.mean(errors)
std_error = np.std(errors)
percentiles = np.percentile(errors, [25, 50, 75])
```

b) **Métricas de Calidad**:
```python
reconstruction_quality = 1 - (error / max_possible_error)
stability_score = 1 / (1 + error_std)
```

## 5. Interpretación Geométrica Avanzada

### 5.1 Espacio de Características
El espacio de características es un espacio vectorial de alta dimensión:

a) **Dimensionalidad**:
- Dimensión original: w × h (dimensiones de ROI)
- Dimensión reducida: k (número de componentes principales)
- Relación: k << w × h

b) **Estructura**:
- Cada punto representa una ROI completa
- Distancias euclidianas reflejan similitud visual
- Clusters indican patrones anatómicos similares

### 5.2 Transformaciones
El proceso involucra múltiples transformaciones:

a) **Transformación PCA**:
```
T: ℝ^(w×h) → ℝ^k
T(x) = V_k^T (x - μ)
```

b) **Reconstrucción**:
```
R: ℝ^k → ℝ^(w×h)
R(ω) = μ + V_k ω
```

c) **Composición**:
```
E = ||x - R(T(x))||₂
```

### 5.3 Topología del Espacio de Búsqueda
El espacio de búsqueda tiene una estructura específica:

a) **Discretización**:
- Malla regular de puntos candidatos
- Resolución determinada por el paso de búsqueda
- Cobertura completa de la región de interés

b) **Conectividad**:
- Vecindad 8-conectada entre puntos
- Transiciones suaves en el error de reconstrucción
- Estructura de gradiente bien definida

### 5.4 Propiedades Geométricas
El sistema exhibe propiedades geométricas importantes:

a) **Invariancia**:
- Rotacional (limitada por discretización)
- Traslacional (dentro de la región de búsqueda)
- Escala (mediante normalización)

b) **Continuidad**:
- Error de reconstrucción continuo
- Gradiente bien definido
- Mínimos locales significativos

## 6. Optimizaciones y Consideraciones Prácticas

### 6.1 Optimización Computacional
a) **Vectorización**:
```python
# Cálculo vectorizado de errores
errors = np.linalg.norm(X - X_reconstructed, axis=1)
```

b) **Precálculo**:
```python
# Proyección de la base PCA
V_k_precomputed = pca.components_[:k].T
mean_precomputed = pca.mean_
```

### 6.2 Gestión de Memoria
a) **Procesamiento por Lotes**:
```python
batch_size = 100
for i in range(0, n_points, batch_size):
    batch = points[i:i+batch_size]
    process_batch(batch)
```

b) **Liberación de Recursos**:
```python
# Limpieza explícita
plt.close('all')
gc.collect()
```

### 6.3 Validación y Control de Calidad
a) **Verificaciones Geométricas**:
```python
def validate_coordinates(coords):
    # Verificar restricciones anatómicas
    distances = calculate_pairwise_distances(coords)
    return check_anatomical_constraints(distances)
```

b) **Control de Errores**:
```python
def check_error_distribution(errors):
    # Análisis estadístico de errores
    z_scores = (errors - np.mean(errors)) / np.std(errors)
    return np.abs(z_scores) < 3  # Identificar valores atípicos
```

## 7. Extensibilidad y Desarrollo Futuro

### 7.1 Arquitectura Modular
- Separación clara de responsabilidades
- Interfaces bien definidas
- Sistema de plugins para extensiones

### 7.2 Mejoras Potenciales
- Paralelización de búsqueda
- Optimización de hiperparámetros
- Integración de técnicas de deep learning

### 7.3 Documentación y Mantenimiento
- Documentación técnica detallada
- Pruebas unitarias y de integración
- Control de versiones y gestión de dependencias
