"""
Utilidades generales para PulmoAlign Viewer.
"""
