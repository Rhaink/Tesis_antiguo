"""
Módulos de interfaz gráfica para PulmoAlign Viewer.
"""
