# PulmoAlign - Documentación Extendida

## Interpretación Geométrica Detallada

### 1. Espacio de Características
- Cada imagen ROI de dimensión w×h se representa como un punto en un espacio ℝ^(w×h)
- El PCA define un nuevo sistema de coordenadas donde los ejes (eigenvectores) apuntan en las direcciones de máxima varianza
- La transformación PCA puede verse como una rotación del espacio que alinea los ejes con las direcciones de máxima variabilidad
- Los puntos en este espacio forman una distribución que refleja la variabilidad anatómica

### 2. Subespacio PCA
- Los k eigenvectores principales definen un subespacio k-dimensional
- Este subespacio captura las variaciones más significativas en la apariencia de los puntos anatómicos
- La proyección en este subespacio minimiza la pérdida de información en términos de varianza explicada
- La base del subespacio (eigenfaces) representa los modos principales de variación

### 3. Distancia de Reconstrucción
- El error de reconstrucción representa la distancia euclidiana entre:
  * El punto original en ℝ^(w×h)
  * Su proyección en el subespacio PCA
- Geométricamente, es la longitud del vector perpendicular al subespacio PCA
- Esta distancia proporciona una medida de cuán bien el subespacio PCA puede representar la imagen
- La minimización de esta distancia equivale a encontrar la mejor representación en el subespacio

### 4. Espacio de Búsqueda
- Las coordenadas de búsqueda definen una malla discreta en el espacio de la imagen
- Cada punto en esta malla representa una posible ubicación del punto anatómico
- El proceso de búsqueda puede visualizarse como un recorrido por esta malla
- La densidad de la malla determina la resolución de la búsqueda
- La topología del espacio de búsqueda influye en la convergencia del algoritmo

### 5. Optimización Geométrica
- La búsqueda del punto óptimo puede interpretarse como:
  * Minimización de la distancia al subespacio PCA
  * Maximización de la similitud con las características principales
  * Búsqueda del punto que mejor se proyecta en el subespacio
- El gradiente del error de reconstrucción define la dirección de mejora
- Los mínimos locales representan posibles ubicaciones del punto anatómico

### 6. Transformaciones Espaciales
- El desplazamiento desde el punto de intersección define una transformación afín
- La normalización de intensidad representa un cambio de escala en el espacio de características
- El SAHS realiza una transformación no lineal del espacio de intensidades
- La combinación de transformaciones preserva la estructura geométrica relevante

## Análisis Estadístico de Errores

### 1. Distribución de Errores
- Se calcula la distribución de errores de reconstrucción para cada punto anatómico
- La distribución proporciona información sobre:
  * La confiabilidad de la detección
  * La variabilidad en la apariencia local
  * La robustez del modelo PCA
- Se analiza la forma de la distribución para detectar anomalías

### 2. Métricas Estadísticas
- Error medio: μₑ = (1/n) ∑ᵢ Eᵢ
- Desviación estándar: σₑ = √[(1/n) ∑ᵢ (Eᵢ - μₑ)²]
- Error mínimo: min{Eᵢ}
- Error máximo: max{Eᵢ}
- Percentiles de error para análisis de robustez
- Coeficiente de variación: CV = σₑ/μₑ

### 3. Análisis de Convergencia
- Se estudia la evolución del error durante la búsqueda
- Se identifica el paso donde se alcanza el mínimo error
- Se analiza la trayectoria de búsqueda para entender el comportamiento
- Se evalúa la velocidad de convergencia
- Se detectan posibles oscilaciones o estancamientos

### 4. Correlación Espacial
- Se analiza la relación entre errores de puntos vecinos
- Se estudia la dependencia espacial de los errores
- Se identifican patrones de error sistemáticos
- Se evalúa la consistencia global de la detección

### 5. Validación Estadística
- Tests de normalidad para las distribuciones de error
- Análisis de valores atípicos
- Intervalos de confianza para las estimaciones
- Pruebas de hipótesis para la significancia de los resultados

## Visualización de Resultados

### 1. Visualización Individual
- Para cada punto anatómico se genera:
  * Mapa de errores de reconstrucción
  * Visualización del camino de búsqueda
  * Comparación entre imagen original y reconstruida
  * Distribución estadística de errores
- Se incluyen marcadores de posición y regiones de interés
- Se visualizan los vectores de desplazamiento

### 2. Visualización Combinada
- Representación global de todos los puntos anatómicos
- Visualización de relaciones espaciales entre puntos
- Análisis de patrones de distribución
- Superposición de resultados múltiples
- Visualización de conectividad entre puntos

### 3. Análisis Visual
- Rostro medio (mean face) que representa la apariencia promedio
- Eigenfaces que capturan los modos principales de variación
- Mapas de error que muestran la calidad de la reconstrucción
- Visualización de componentes principales
- Representación de la varianza explicada

### 4. Métricas Visuales
- Gráficos de distribución de errores
- Visualización de trayectorias de búsqueda
- Representación de regiones de confianza
- Mapas de calor de error
- Diagramas de dispersión de resultados

### 5. Herramientas Interactivas
- Visualización de resultados paso a paso
- Comparación interactiva de métodos
- Exploración de parámetros
- Análisis de sensibilidad visual
- Herramientas de validación visual

## Consideraciones de Implementación

### 1. Eficiencia Computacional
- Uso de NumPy para operaciones matriciales optimizadas
- Implementación vectorizada de cálculos PCA
- Procesamiento eficiente de imágenes con OpenCV
- Paralelización de operaciones independientes
- Optimización de memoria en cálculos intensivos

### 2. Robustez
- Manejo de casos límite en bordes de imagen
- Validación de coordenadas y dimensiones
- Tratamiento de errores en carga y procesamiento
- Detección y manejo de valores atípicos
- Verificación de integridad de datos

### 3. Extensibilidad
- Diseño modular que permite agregar nuevas funcionalidades
- Interfaz clara para implementar nuevos métodos de análisis
- Capacidad de adaptación a diferentes tipos de imágenes
- Sistema de plugins para extensiones
- Documentación completa para desarrolladores

### 4. Mantenibilidad
- Código bien documentado y estructurado
- Tests unitarios y de integración
- Control de versiones
- Gestión de dependencias
- Guías de contribución
