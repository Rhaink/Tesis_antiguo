# PulmoAlign

Biblioteca especializada para el procesamiento y análisis de imágenes pulmonares mediante técnicas avanzadas de alineación y análisis de componentes principales (PCA). Este proyecto implementa un sistema robusto para la detección y alineación automática de puntos anatómicos clave en radiografías pulmonares.

## Descripción Técnica del Proceso

El proceso de alineación se divide en varias etapas principales, cada una implementando algoritmos específicos:

### 1. Gestión de Coordenadas
El sistema utiliza un conjunto de 15 puntos anatómicos clave (landmarks) distribuidos estratégicamente en la radiografía pulmonar. Para cada punto se define:

- Región de interés (ROI) con dimensiones específicas
- Puntos de referencia superior, inferior, izquierdo y derecho
- Centro geométrico calculado como:
  ```
  center_x = (left + right) / 2
  center_y = (sup + inf) / 2
  ```

La configuración de cada punto incluye:
- Dimensiones específicas de la ROI (width × height)
- Puntos de referencia para el cálculo del centro y la intersección
- Desplazamiento desde el punto de intersección para el ajuste fino:
  ```
  dx = new_x - intersection_x
  dy = new_y - intersection_y
  new_center_x = center_x + dx
  new_center_y = center_y + dy
  ```

### 2. Procesamiento de Imágenes
El procesamiento de imágenes incluye varias transformaciones:

a) **Normalización**: Las imágenes se normalizan en el rango [0,1]:
```
I_norm = I / 255
```

b) **Mejoramiento de Contraste (SAHS)**:
El algoritmo Statistical Asymmetric Histogram Stretching (SAHS) realiza un análisis estadístico asimétrico del histograma:

1. Cálculo de la media global:
   ```
   μ = (1/N) ∑ᵢ I(i)
   ```

2. Separación de píxeles:
   - Grupo superior: G₁ = {I(i) | I(i) > μ}
   - Grupo inferior: G₂ = {I(i) | I(i) ≤ μ}

3. Cálculo de desviaciones estándar asimétricas:
   ```
   σ₁ = √[(1/|G₁|) ∑_{i∈G₁} (I(i) - μ)²]
   σ₂ = √[(1/|G₂|) ∑_{i∈G₂} (I(i) - μ)²]
   ```

4. Determinación de límites:
   ```
   max_value = μ + 2.5σ₁
   min_value = μ - 2.0σ₂
   ```

5. Normalización final:
   ```
   I_enhanced = 255 * (I - min_value)/(max_value - min_value)
   ```

c) **Extracción de ROI**: Para cada punto anatómico se extrae una región de interés considerando:
- Centro de la región
- Dimensiones predefinidas (width × height)
- Desplazamiento desde el punto de intersección
- Redimensionamiento y normalización de la región extraída

### 3. Análisis de Componentes Principales (PCA)

El análisis PCA se implementa en varios pasos:

a) **Preparación de Datos**:
- Las imágenes se vectorizan: X ∈ ℝ^(n×d), donde n es el número de imágenes y d es la dimensionalidad
- Se calcula la imagen media (mean face):
  ```
  μ = (1/n) ∑ᵢ xᵢ
  ```

b) **Cálculo de Componentes Principales**:
- Se construye la matriz de covarianza:
  ```
  C = (1/n) ∑ᵢ (xᵢ - μ)(xᵢ - μ)ᵀ
  ```
- Se calculan los eigenvalores (λ) y eigenvectores (v):
  ```
  Cv = λv
  ```

c) **Selección de Componentes**:
- Se seleccionan k componentes basados en la varianza explicada:
  ```
  k = argmin_{m} {∑ᵢ₌₁ᵐ λᵢ / ∑ᵢ₌₁ⁿ λᵢ ≥ threshold}
  ```
- El umbral típico es 0.95 (95% de la varianza explicada)

d) **Proyección y Reconstrucción**:
- Proyección en el espacio PCA:
  ```
  ω = Vᵀ(x - μ)
  ```
- Reconstrucción de la imagen:
  ```
  x̂ = μ + Vω
  ```

### 4. Búsqueda de Correspondencias

Para cada punto anatómico:

a) **Error de Reconstrucción**:
- Se calcula el error L2 entre la imagen original y su reconstrucción:
  ```
  E = ||x - x̂||₂
  ```

b) **Optimización**:
- Se busca la posición que minimiza el error de reconstrucción:
  ```
  (x*, y*) = argmin_{(x,y)} E(x,y)
  ```

c) **Proceso de Búsqueda**:
1. Para cada coordenada candidata en la región de búsqueda:
   - Se extrae la ROI centrada en la coordenada
   - Se normaliza y procesa con SAHS
   - Se proyecta en el espacio PCA
   - Se reconstruye y calcula el error

2. Se selecciona la coordenada con el menor error de reconstrucción:
   ```
   (x*, y*) = argmin_{(x,y)∈S} E(x,y)
   ```
   donde S es el conjunto de coordenadas de búsqueda.

### 5. Interpretación Geométrica

El proceso puede interpretarse geométricamente como:

a) **Espacio de Características**:
- Cada imagen ROI de dimensión w×h se representa como un punto en un espacio ℝ^(w×h)
- El PCA define un nuevo sistema de coordenadas donde los ejes (eigenvectores) apuntan en las direcciones de máxima varianza

b) **Subespacio PCA**:
- Los k eigenvectores principales definen un subespacio k-dimensional
- Este subespacio captura las variaciones más significativas en la apariencia de los puntos anatómicos

c) **Distancia de Reconstrucción**:
- El error de reconstrucción representa la distancia euclidiana entre:
  * El punto original en ℝ^(w×h)
  * Su proyección en el subespacio PCA
- Geométricamente, es la longitud del vector perpendicular al subespacio PCA

## Estructura del Proyecto

```
pulmo_align/
├── pulmo_align/
│   ├── coordinates/          # Gestión de coordenadas
│   │   └── coordinate_manager.py
│   ├── image_processing/     # Procesamiento de imágenes
│   │   ├── image_processor.py
│   │   └── contrast_enhancer.py
│   ├── pca_analysis/        # Análisis PCA
│   │   └── pca_analyzer.py
│   ├── visualization/       # Visualización
│   │   ├── visualizer.py
│   │   └── combined_visualizer.py
│   ├── scripts/            # Scripts principales
│   │   ├── extract_cropped_images.py
│   │   ├── analyze_pca_errors.py
│   │   └── test_contrast_enhancement.py
│   └── __init__.py
├── setup.py
└── README.md
```

## Descripción de los Módulos

### 1. Coordinates (coordinates/)
- `coordinate_manager.py`: Gestiona la configuración y procesamiento de coordenadas
  - Lectura de coordenadas desde archivos CSV/JSON
  - Cálculo de centros e intersecciones
  - Validación de coordenadas
  - Gestión de configuraciones específicas para cada punto anatómico

### 2. Image Processing (image_processing/)
- `image_processor.py`: Procesamiento de imágenes
  - Carga y redimensionamiento
  - Extracción de ROIs
  - Normalización y preprocesamiento
  - Gestión de rutas y almacenamiento
- `contrast_enhancer.py`: Mejoramiento de contraste
  - Implementación del algoritmo SAHS
  - Análisis estadístico del histograma
  - Normalización adaptativa

### 3. PCA Analysis (pca_analysis/)
- `pca_analyzer.py`: Implementación del análisis PCA
  - Entrenamiento de modelos PCA
  - Cálculo de eigenfaces
  - Análisis de errores de reconstrucción
  - Búsqueda de correspondencias óptimas
  - Gestión de componentes principales

### 4. Visualization (visualization/)
- `visualizer.py`: Herramientas de visualización
  - Generación de gráficos de resultados
  - Visualización de distribuciones de error
  - Representación de caminos de búsqueda
- `combined_visualizer.py`: Visualización combinada
  - Integración de múltiples resultados
  - Comparación de métodos

### 5. Scripts (scripts/)
- `extract_cropped_images.py`: Extracción de ROIs
- `analyze_pca_errors.py`: Análisis de errores PCA
- `test_contrast_enhancement.py`: Pruebas de mejora de contraste

## Requisitos

- Python >= 3.6
- NumPy
- OpenCV (cv2)
- Pandas
- Matplotlib
- scikit-learn

## Instalación y Uso

### Método 1: Instalación para Desarrollo

1. Clonar el repositorio:
```bash
git clone <repository-url>
cd pulmo_align
```

2. Instalar las dependencias:
```bash
pip install -e .
```

### Método 2: Instalación Portable

1. Crear el paquete distribuible:
```bash
# En el directorio raíz del proyecto
python setup.py sdist
```
Esto creará un archivo `pulmo_align-0.1.0.tar.gz` en el directorio `dist/` que se generará automáticamente.

2. Distribuir e instalar el paquete:
```bash
# En el sistema destino
pip install pulmo_align-0.1.0.tar.gz
```

3. Estructura de archivos necesaria:
```
directorio_trabajo/
├── coordenadas.csv        # Archivo con coordenadas de puntos anatómicos
├── indices.csv           # Archivo con índices de imágenes
├── all_search_coordinates.json  # Coordenadas de búsqueda
└── COVID-19_Radiography_Dataset/  # Dataset de imágenes
    ├── COVID/
    │   └── images/
    ├── Normal/
    │   └── images/
    └── Viral Pneumonia/
        └── images/
```

## Ejemplos de Uso

### 1. Extracción de Imágenes Recortadas

```python
from pulmo_align.scripts.extract_cropped_images import process_images

# Procesar imágenes
results = process_images(
    coordinates_file='coordenadas.csv',
    indices_file='indices.csv'
)
```

### 2. Análisis PCA y Búsqueda de Errores

```python
from pulmo_align.coordinates.coordinate_manager import CoordinateManager
from pulmo_align.image_processing.image_processor import ImageProcessor
from pulmo_align.visualization.visualizer import Visualizer
from pulmo_align.pca_analysis.pca_analyzer import PCAAnalyzer
from pulmo_align.scripts.analyze_pca_errors import process_image, initialize_pca_models

# Inicializar componentes
coord_manager = CoordinateManager()
image_processor = ImageProcessor()
visualizer = Visualizer()

# Cargar coordenadas y modelos PCA
coord_manager.read_search_coordinates('all_search_coordinates.json')
pca_models = initialize_pca_models(coord_manager, image_processor, 'indices.csv')

# Procesar imagen
process_image(
    image_path='imagen.png',
    coord_manager=coord_manager,
    image_processor=image_processor,
    pca_models=pca_models,
    visualizer=visualizer
)
```

## Contribución

1. Fork el repositorio
2. Cree una rama para su característica (`git checkout -b feature/amazing-feature`)
3. Commit sus cambios (`git commit -m 'Add some amazing feature'`)
4. Push a la rama (`git push origin feature/amazing-feature`)
5. Abra un Pull Request

## Licencia

Este proyecto está licenciado bajo los términos de la licencia MIT.
